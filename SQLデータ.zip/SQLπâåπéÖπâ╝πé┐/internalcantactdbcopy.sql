Last login: Sat May  7 17:06:42 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c axizuser
FATAL:  database "axizuser" does not exist
Previous connection kept
postgres=# \c postgres axizuser
Password for user axizuser: 
You are now connected to database "postgres" as user "axizuser".
postgres=> \c internalcontactdb
You are now connected to database "internalcontactdb" as user "axizuser".
internalcontactdb=> select user_id from users;
internalcontactdb=> create database internalcontactdbcopy;
CREATE DATABASE
internalcontactdb-> \c internalcontactdbcopy;
You are now connected to database "internalcontactdbcopy" as user "axizuser".
internalcontactdbcopy=> create table role (
internalcontactdbcopy(> role_id int primary key,
internalcontactdbcopy(> role_name varchar(50)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> insert into  role (role_id, role_name)values
internalcontactdbcopy-> (1,'管理者'),(2,'一般'),(3,'リーダー');
INSERT 0 3
internalcontactdbcopy=> select * from role;
 role_id | role_name 
---------+-----------
       1 | 管理者
       2 | 一般
       3 | リーダー
(3 rows)

internalcontactdbcopy=> create table users(
internalcontactdbcopy(> user_id serial primary key,
internalcontactdbcopy(> user_name varchar(50),
internalcontactdbcopy(> login_id varchar(50),
internalcontactdbcopy(> password varchar(50),
internalcontactdbcopy(> tel_no varchar(50),
internalcontactdbcopy(> role_id int not null references role(role_id)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> insert into users(user_name, login_id,tel_no,role_id)values
internalcontactdbcopy-> ('伊藤荘','sou@gimal.com','sou54987',1),
internalcontactdbcopy-> ('松村荘','hama@gimal.com','82364460',2);
INSERT 0 2
internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |  tel_no  | role_id 
---------+-----------+----------------+----------+----------+---------
       1 | 伊藤荘    | sou@gimal.com  |          | sou54987 |       1
       2 | 松村荘    | hama@gimal.com |          | 82364460 |       2
(2 rows)

internalcontactdbcopy=> UPDATE users SET tel_no = '09078665432' WHERE user_id = 1;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET password = 'sou54987' WHERE user_id = 1;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET tel_no = '09078667543' WHERE user_id = 2;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET password = 'hama7865' WHERE user_id = 2;
UPDATE 1
internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |   tel_no    | role_id 
---------+-----------+----------------+----------+-------------+---------
       1 | 伊藤荘    | sou@gimal.com  | sou54987 | 09078665432 |       1
       2 | 松村荘    | hama@gimal.com | hama7865 | 09078667543 |       2
(2 rows)

internalcontactdbcopy=> create table groups(
internalcontactdbcopy(> group_id serial primary key,
internalcontactdbcopy(> group_name varchar(50)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> insert into groups(group_name)values
internalcontactdbcopy-> ('社内'),('システム部');
INSERT 0 2
internalcontactdbcopy=> select * from groups;
 group_id | group_name 
----------+------------
        1 | 社内
        2 | システム部
(2 rows)

internalcontactdbcopy=> create table message(
internalcontactdbcopy(> message_id serial primary key,
internalcontactdbcopy(> messaae_title varchar(50),
internalcontactdbcopy(> message_text text,
internalcontactdbcopy(> date timestamp,
internalcontactdbcopy(> user_id int not null references users(user_id),
internalcontactdbcopy(> group_id int not null references groups(group_id)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> alter table message rename column  timestamp to create_datatime;
ERROR:  column "timestamp" does not exist
internalcontactdbcopy=> \d message;
internalcontactdbcopy=> alter table message alter column date type date;
ALTER TABLE
internalcontactdbcopy=> \d message
internalcontactdbcopy=> alter table message rename column date to create_datatime;
ALTER TABLE
internalcontactdbcopy=> \d message
internalcontactdbcopy=> alter table message rename column messaae_title 
internalcontactdbcopy-> to message_title;
ALTER TABLE
internalcontactdbcopy=> insert into (message_title,message_text,create_datatime,
internalcontactdbcopy(> user_id,group_id)values
internalcontactdbcopy-> ('社内日報','本日の内容は','2022/2/18',1,1),
internalcontactdbcopy-> ('システム研修','2月16日に','2022/2/18',1,2);
ERROR:  syntax error at or near "("
LINE 1: insert into (message_title,message_text,create_datatime,
                    ^
internalcontactdbcopy=> insert into message (message_title,message_text,create_datatime,
internalcontactdbcopy(> user_id,group_id)values
internalcontactdbcopy-> ('社内日報','本日の内容は','2022/2/18',1,1),
internalcontactdbcopy-> ('システム研修','2月16日に','2022/2/18',1,2);
INSERT 0 2
internalcontactdbcopy=> select * from message;
 message_id | message_title | message_text | create_datatime | user_id | group_id 
------------+---------------+--------------+-----------------+---------+----------
          1 | 社内日報      | 本日の内容は | 2022-02-18      |       1 |        1
          2 | システム研修  | 2月16日に    | 2022-02-18      |       1 |        2
(2 rows)

internalcontactdbcopy=> 
