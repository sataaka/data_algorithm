Last login: Thu Mar  3 07:57:56 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c postgres axizuser
dbconnection=> select * from users where login_id = 'sou.@gmail.com' and
dbconnection-> password = '54926472';
ERROR:  relation "users" does not exist
LINE 1: select * from users where login_id = 'sou.@gmail.com' and
                      ^
dbconnection=> select * from users;
ERROR:  relation "users" does not exist
LINE 1: select * from users;
                      ^
dbconnection=> \c internalcontactdb
You are now connected to database "internalcontactdb" as user "axizuser".
internalcontactdb=> select * from users where login_id = 'sou.@gmail.com' and
internalcontactdb-> password = '54926472';
 user_id | user_name |    login_id    | password |  tel_no  | role_id 
---------+-----------+----------------+----------+----------+---------
       1 | 伊藤壮    | sou.@gmail.com | 54926472 | 54926472 |       1
(1 row)

internalcontactdb=> select user_id, group_name
internalcontactdb-> from user_group join groups
internalcontactdb-> on user_group.group_id = groups.group_id;
 user_id | group_name 
---------+------------
       1 | 社内
       1 | システム部
       2 | 社内
       2 | システム部
(4 rows)

internalcontactdb=> select group_name, user_name from groups join 
internalcontactdb-> user_group on groups.group_id = user_group.group_id;
ERROR:  column "user_name" does not exist
LINE 1: select group_name, user_name from groups join 
                           ^
internalcontactdb=> group_name, management_id from groups join
internalcontactdb-> user_group on groups.group_id = user_group.group_id;
ERROR:  syntax error at or near "group_name"
LINE 1: group_name, management_id from groups join
        ^
internalcontactdb=> selsect group_name, management_id from groups join
internalcontactdb-> user_group on groups.group_id = user_group.group_id;
ERROR:  syntax error at or near "selsect"
LINE 1: selsect group_name, management_id from groups join
        ^
internalcontactdb=> select group_name, management_id from groups join
internalcontactdb-> user_group on groups.group_id = user_group.group_id;
 group_name | management_id 
------------+---------------
 社内       |             1
 システム部 |             2
 社内       |             3
 システム部 |             4
(4 rows)

internalcontactdb=> select group_name,user_id from groups join
internalcontactdb-> user_group on groups.group_id = user_group.group_id;
 group_name | user_id 
------------+---------
 社内       |       1
 システム部 |       1
 社内       |       2
 システム部 |       2
(4 rows)

internalcontactdb=> SELECT user_id, group_name FROM user_group JOIN groups ON user_group.group_id = groups.group_id
internalcontactdb-> ;
 user_id | group_name 
---------+------------
       1 | 社内
       1 | システム部
       2 | 社内
       2 | システム部
(4 rows)

internalcontactdb=> select group_name from groups;
 group_name 
------------
 社内
 システム部
(2 rows)

internalcontactdb=> insert into groups (group_name)
internalcontactdb-> values('事務課');
INSERT 0 1
internalcontactdb=> select * from groups;
 group_id | group_name 
----------+------------
        1 | 社内
        2 | システム部
        3 | 事務課
(3 rows)

internalcontactdb=> select user_id,group_name from user_group join
internalcontactdb-> groups on user_group.group_id = groups.group_id where 
internalcontactdb-> user_id = 1;
 user_id | group_name 
---------+------------
       1 | 社内
       1 | システム部
(2 rows)

internalcontactdb=> select
internalcontactdb-> user_group.user_id,users.name
internalcontactdb-> from
internalcontactdb-> user_group
internalcontactdb-> join
internalcontactdb-> users
internalcontactdb-> on
internalcontactdb-> user_group.user_id = users.user_id
internalcontactdb-> right join
internalcontactdb-> groups
internalcontactdb-> on
internalcontactdb-> user_group.group_id = groups.group_id
internalcontactdb-> weher
internalcontactdb-> group_name = '社内';
ERROR:  syntax error at or near "weher"
LINE 13: weher
         ^
internalcontactdb=> select user_group.user_id,users.name
internalcontactdb-> from user_group join users on
internalcontactdb-> user_group.user_id = users.user_id
internalcontactdb-> right join
internalcontactdb-> groups on 
internalcontactdb-> user_group.group_id = groups.group_id
internalcontactdb-> where group_name = '社内';
ERROR:  column users.name does not exist
LINE 1: select user_group.user_id,users.name
                                  ^
internalcontactdb=> select user_group.user_id,users.user_name
internalcontactdb-> from user_group join users on
internalcontactdb-> user_group.user_id = users.user_id
internalcontactdb-> right join
internalcontactdb-> groups on
internalcontactdb-> user_group.group_id = groups.group_id
internalcontactdb-> where group_name = '社内';
 user_id | user_name 
---------+-----------
       1 | 伊藤壮
       2 | 松村浜
(2 rows)

internalcontactdb=> 
