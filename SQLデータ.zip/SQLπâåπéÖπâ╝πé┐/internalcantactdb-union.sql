Last login: Thu Mar 24 17:45:51 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c postgres axizuser
Password for user axizuser: 
You are now connected to database "postgres" as user "axizuser".
postgres=> \c internalcontactdb
You are now connected to database "internalcontactdb" as user "axizuser".
internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,message.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> where message_title = '社内日報'
internalcontactdb-> or user_name = '伊藤壮'
internalcontactdb-> or to_char(message.create_datatime, 'yyyy/mm/dd') 
internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> rigth join groups on message.group_id = groups.group_id
internalcontactdb-> where message_title = '社内日報'
internalcontactdb-> or user_name = '伊藤壮'
internalcontactdb-> or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18'
internalcontactdb-> and groups.group_id = 1;
ERROR:  syntax error at or near "rigth"
LINE 6: rigth join groups on message.group_id = groups.group_id
        ^
internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where message_title = '社内日報'
internalcontactdb-> or user_name = '伊藤壮'
internalcontactdb-> or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18'
internalcontactdb-> and groups.group_id = 1;
 message_id | message_title |             message_text             | create_datatime | user_id | group_id |        user_name         
------------+---------------+--------------------------------------+-----------------+---------+----------+--------------------------
          3 | 社内日報      | 本日の業務は                         | 2023-02-18      |       1 |        1 | 伊藤壮
          6 | 社内日報      | 本日の内容は・・・                   | 2022-02-18      |       1 |        1 | 伊藤壮
          8 | 研修          | テスト                               | 2023-02-18      |       1 |        1 | 伊藤壮
         15 | 社内日報      | 今日の業務連絡としては、\r          +| 2022-02-18      |       1 |        1 | 伊藤壮
            |               | 管理者画面の作成をすることができた。 |                 |         |          | 
         17 | 社内日報      | テスト                               | 2022-02-18      |      23 |        1 | 田井戸
         23 | 社内日報      | テスト                               | 2022-03-23      |      50 |        1 | 平平平平臍下珍内春寒衛門
          7 | システム研    | 2月16日に・                          | 2022-02-19      |       1 |        2 | 伊藤壮
         11 | 研修内容      | テスト                               | 2022-02-18      |       1 |        2 | 伊藤壮
         18 | 研修日報      | テスト                               | 2022-03-22      |       1 |        2 | 伊藤壮
         16 | 社内日報      | テスト                               | 2022-02-18      |      23 |        2 | 田井戸
         14 | 社内日報      | テスト                               | 2022-02-18      |      28 |        3 | 田井戸回
         13 | 社内日報      | テスト                               | 2022-02-18      |       1 |        6 | 伊藤壮
(12 rows)

internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where groups.group_id = 1 and message_title = '社内日報'
internalcontactdb-> or user_name = '伊藤壮' or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18';
 message_id | message_title |             message_text             | create_datatime | user_id | group_id |        user_name         
------------+---------------+--------------------------------------+-----------------+---------+----------+--------------------------
          3 | 社内日報      | 本日の業務は                         | 2023-02-18      |       1 |        1 | 伊藤壮
          6 | 社内日報      | 本日の内容は・・・                   | 2022-02-18      |       1 |        1 | 伊藤壮
          8 | 研修          | テスト                               | 2023-02-18      |       1 |        1 | 伊藤壮
         15 | 社内日報      | 今日の業務連絡としては、\r          +| 2022-02-18      |       1 |        1 | 伊藤壮
            |               | 管理者画面の作成をすることができた。 |                 |         |          | 
         17 | 社内日報      | テスト                               | 2022-02-18      |      23 |        1 | 田井戸
         23 | 社内日報      | テスト                               | 2022-03-23      |      50 |        1 | 平平平平臍下珍内春寒衛門
          7 | システム研    | 2月16日に・                          | 2022-02-19      |       1 |        2 | 伊藤壮
         11 | 研修内容      | テスト                               | 2022-02-18      |       1 |        2 | 伊藤壮
         18 | 研修日報      | テスト                               | 2022-03-22      |       1 |        2 | 伊藤壮
         13 | 社内日報      | テスト                               | 2022-02-18      |       1 |        6 | 伊藤壮
(10 rows)

internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where groups.group_id = 1 and message.user_id = 1 and  message_title = '社内日報'
internalcontactdb-> or user_name = '伊藤壮' or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18';
 message_id | message_title |             message_text             | create_datatime | user_id | group_id | user_name 
------------+---------------+--------------------------------------+-----------------+---------+----------+-----------
          3 | 社内日報      | 本日の業務は                         | 2023-02-18      |       1 |        1 | 伊藤壮
          6 | 社内日報      | 本日の内容は・・・                   | 2022-02-18      |       1 |        1 | 伊藤壮
          8 | 研修          | テスト                               | 2023-02-18      |       1 |        1 | 伊藤壮
         15 | 社内日報      | 今日の業務連絡としては、\r          +| 2022-02-18      |       1 |        1 | 伊藤壮
            |               | 管理者画面の作成をすることができた。 |                 |         |          | 
          7 | システム研    | 2月16日に・                          | 2022-02-19      |       1 |        2 | 伊藤壮
         11 | 研修内容      | テスト                               | 2022-02-18      |       1 |        2 | 伊藤壮
         18 | 研修日報      | テスト                               | 2022-03-22      |       1 |        2 | 伊藤壮
         13 | 社内日報      | テスト                               | 2022-02-18      |       1 |        6 | 伊藤壮
(8 rows)

internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where groups.group_id = 1 and message.user_id = 1 and  message_title = '社内日報'
internalcontactdb-> and user_name = '伊藤壮' and to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18';
 message_id | message_title | message_text | create_datatime | user_id | group_id | user_name 
------------+---------------+--------------+-----------------+---------+----------+-----------
(0 rows)

internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where message_title = '社内日報' or user_name = '伊藤壮' or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18'
internalcontactdb-> and groups.groupid between 1 and 1;
ERROR:  column groups.groupid does not exist
LINE 8: and groups.groupid between 1 and 1;
            ^
HINT:  Perhaps you meant to reference the column "groups.group_id".
internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where message_title = '社内日報' or user_name = '伊藤壮' or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18'
internalcontactdb-> and groups.group_id between 1 and 1;
 message_id | message_title |             message_text             | create_datatime | user_id | group_id |        user_name         
------------+---------------+--------------------------------------+-----------------+---------+----------+--------------------------
          3 | 社内日報      | 本日の業務は                         | 2023-02-18      |       1 |        1 | 伊藤壮
          6 | 社内日報      | 本日の内容は・・・                   | 2022-02-18      |       1 |        1 | 伊藤壮
          8 | 研修          | テスト                               | 2023-02-18      |       1 |        1 | 伊藤壮
         15 | 社内日報      | 今日の業務連絡としては、\r          +| 2022-02-18      |       1 |        1 | 伊藤壮
            |               | 管理者画面の作成をすることができた。 |                 |         |          | 
         17 | 社内日報      | テスト                               | 2022-02-18      |      23 |        1 | 田井戸
         23 | 社内日報      | テスト                               | 2022-03-23      |      50 |        1 | 平平平平臍下珍内春寒衛門
          7 | システム研    | 2月16日に・                          | 2022-02-19      |       1 |        2 | 伊藤壮
         11 | 研修内容      | テスト                               | 2022-02-18      |       1 |        2 | 伊藤壮
         18 | 研修日報      | テスト                               | 2022-03-22      |       1 |        2 | 伊藤壮
         16 | 社内日報      | テスト                               | 2022-02-18      |      23 |        2 | 田井戸
         14 | 社内日報      | テスト                               | 2022-02-18      |      28 |        3 | 田井戸回
         13 | 社内日報      | テスト                               | 2022-02-18      |       1 |        6 | 伊藤壮
(12 rows)

internalcontactdb=> select message.message_id,message_title,
internalcontactdb-> message.message_text,message.create_datatime,
internalcontactdb-> message.user_id,groups.group_id,
internalcontactdb-> users.user_name from message join users
internalcontactdb-> on message.user_id = users.user_id
internalcontactdb-> right join groups on message.group_id = groups.group_id
internalcontactdb-> where message_title = '社内日報' or user_name = '伊藤壮' or to_char(message.create_datatime, 'yyyy/mm/dd') = '2022/2/18'
internalcontactdb-> and groups.group_id HAVING COUNT(*) < 2;
ERROR:  argument of AND must be type boolean, not type integer
LINE 8: and groups.group_id HAVING COUNT(*) < 2;
            ^
internalcontactdb=> select group_name,case when group_id > 20 '合格' 
internalcontactdb-> else '不合格' end from groups;
ERROR:  syntax error at or near "'合格'"
LINE 1: select group_name,case when group_id > 20 '合格'
                                                  ^
internalcontactdb=> select group_name,case when group_id > 20 then '合格'
internalcontactdb-> else '不合格' end from groups;
 group_name  |  case  
-------------+--------
 社内        | 不合格
 システム部  | 不合格
 事務課      | 不合格
 Linux       | 合格
 css         | 合格
 Webデザイン | 不合格
 経理部      | 不合格
 経理部門    | 合格
 css         | 合格
 Mac         | 合格
 enjinya     | 合格
 Android     | 合格
 管理部門    | 合格
(13 rows)

internalcontactdb=> select * from groups 
internalcontactdb-> where
internalcontactdb-> (case when group_id >= 20 then 'a' end) = 'a';
 group_id | group_name 
----------+------------
      125 | Linux
      126 | css
       68 | 経理部門
       95 | css
       97 | Mac
       42 | enjinya
       44 | Android
       45 | 管理部門
(8 rows)

internalcontactdb=> select message.message_title from message
internalcontactdb-> where
internalcontactdb-> (case when group_id <=1 then)
internalcontactdb-> ;
ERROR:  syntax error at or near ")"
LINE 3: (case when group_id <=1 then)
                                    ^
internalcontactdb=> select message.message_title from message
internalcontactdb-> where
internalcontactdb-> (case when group_id <=1 then message_title end) 
internalcontactdb-> = message_title;
 message_title 
---------------
 社内日報
 社内日報
 研修
 社内日報
 社内日報
 社内日報
(6 rows)

internalcontactdb=> select message.message_title from message
internalcontactdb-> where
internalcontactdb-> (case when group_id <=1 then message_title = '社内日報'
internalcontactdb(> end) = message_title = '社内日報';
ERROR:  syntax error at or near "="
LINE 4: end) = message_title = '社内日報';
                             ^
internalcontactdb=> select message.message_id,message.message_title, message.message_text,message.create_datatime,
internalcontactdb-> message.user_id, message.group_id,
internalcontactdb-> groups.group_name
internalcontactdb-> from message join groups
internalcontactdb-> on message.group_id = groups.group_id where groups.group_id
internalcontactdb-> = 1 and message_title = '社内日報' and 
internalcontactdb-> to_char(message.create_datatime, 'yyyy/mm/dd') 
internalcontactdb-> = '2022/2/18;'
internalcontactdb=> select message.message_id,message.message_title, message.message_text,message.create_datatime,
internalcontactdb-> message.user_id, message.group_id,
internalcontactdb-> groups.group_name
internalcontactdb-> from message join groups
internalcontactdb-> on message.group_id = groups.group_id where groups.group_id
internalcontactdb-> = 1 and message_title = '社内日報' or
internalcontactdb-> to_char(message.create_datatime, 'yyyy/mm/dd') 
internalcontactdb-> = '2022/02/18';
internalcontactdb=> select message_title as '社内日報' from message;
ERROR:  syntax error at or near "'社内日報'"
LINE 1: select message_title as '社内日報' from message;
                                ^
internalcontactdb=> select from group_name as 'グループ名' from groups;
ERROR:  syntax error at or near "'グループ名'"
LINE 1: select from group_name as 'グループ名' from groups;
                                  ^
internalcontactdb=> select group_name as 'グループ名' from groups;
ERROR:  syntax error at or near "'グループ名'"
LINE 1: select group_name as 'グループ名' from groups;
                             ^
internalcontactdb=> select group_name from groups;
 group_name  
-------------
 社内
 システム部
 事務課
 Linux
 css
 Webデザイン
 経理部
 経理部門
 css
 Mac
 enjinya
 Android
 管理部門
(13 rows)

internalcontactdb=> select
internalcontactdb-> group_name AS '名前'
internalcontactdb-> from groups;
ERROR:  syntax error at or near "'名前'"
LINE 2: group_name AS '名前'
                      ^
internalcontactdb=> select
internalcontactdb-> group_name AS 名前
internalcontactdb-> from groups;
    名前     
-------------
 社内
 システム部
 事務課
 Linux
 css
 Webデザイン
 経理部
 経理部門
 css
 Mac
 enjinya
 Android
 管理部門
(13 rows)

internalcontactdb=> select message_title as タイトル
internalcontactdb-> union 
internalcontactdb-> select message_title as テキスト;
ERROR:  column "message_title" does not exist
LINE 1: select message_title as タイトル
               ^
internalcontactdb=> select user_id from message
internalcontactdb-> union
internalcontactdb-> select message_title,groups;
ERROR:  relation "group_id" does not exist
LINE 1: select groups, message from group_id union
                                    ^
internalcontactdb=> select * from message
internalcontactdb-> union select * from groups;
ERROR:  each UNION query must have the same number of columns
LINE 2: union select * from groups;
                     ^
internalcontactdb=> select message_title from message
internalcontactdb-> union select group_name from groups;
 message_title 
---------------
 Android
 事務課
 経理部門
 社内
 研修
 Webデザイン
 経理部
 Linux
 管理部門
 システム研
 enjinya
 社内日報
 システム部
 研修日報
 css
 Mac
 研修内容
(17 rows)

internalcontactdb=> select message_title from message
internalcontactdb-> union selct group_id from groups where group_id =1;
ERROR:  syntax error at or near "selct"
LINE 2: union selct group_id from groups where group_id =1;
              ^
internalcontactdb=> select message_title from message
internalcontactdb-> union select group_name from groups
internalcontactdb-> where group_name = '社内';
 message_title 
---------------
 社内日報
 研修日報
 社内
 研修
 研修内容
 システム研
(6 rows)

internalcontactdb=> select message_title from message 
internalcontactdb-> where message_tite = '社内日報'
internalcontactdb-> union select group_name from groups
internalcontactdb-> where group_name = '社内';
ERROR:  column "message_tite" does not exist
LINE 2: where message_tite = '社内日報'
              ^
HINT:  Perhaps you meant to reference the column "message.message_title".
internalcontactdb=> select message_title from message 
internalcontactdb-> where message_title = '社内日報' or
internalcontactdb-> to_char(message.create_datatime, 'yyyy/mm/dd') 
internalcontactdb-> = '2022/02/18' 
internalcontactdb-> union select group_name from groups
internalcontactdb-> where group_name = '社内';
 message_title 
---------------
 社内
 研修内容
 社内日報
(3 rows)

internalcontactdb=> 
