Last login: Sat May  7 17:06:42 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c axizuser
FATAL:  database "axizuser" does not exist
Previous connection kept
postgres=# \c postgres axizuser
Password for user axizuser: 
You are now connected to database "postgres" as user "axizuser".
postgres=> \c internalcontactdb
You are now connected to database "internalcontactdb" as user "axizuser".
internalcontactdb=> select user_id from users;
internalcontactdb=> create database internalcontactdbcopy;
CREATE DATABASE
internalcontactdb-> \c internalcontactdbcopy;
You are now connected to database "internalcontactdbcopy" as user "axizuser".
internalcontactdbcopy=> create table role (
internalcontactdbcopy(> role_id int primary key,
internalcontactdbcopy(> role_name varchar(50)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> insert into  role (role_id, role_name)values
internalcontactdbcopy-> (1,'管理者'),(2,'一般'),(3,'リーダー');
INSERT 0 3
internalcontactdbcopy=> select * from role;
 role_id | role_name 
---------+-----------
       1 | 管理者
       2 | 一般
       3 | リーダー
(3 rows)

internalcontactdbcopy=> create table users(
internalcontactdbcopy(> user_id serial primary key,
internalcontactdbcopy(> user_name varchar(50),
internalcontactdbcopy(> login_id varchar(50),
internalcontactdbcopy(> password varchar(50),
internalcontactdbcopy(> tel_no varchar(50),
internalcontactdbcopy(> role_id int not null references role(role_id)
internalcontactdbcopy(> );
CREATE TABLE
internalcontactdbcopy=> insert into users(user_name, login_id,tel_no,role_id)values
internalcontactdbcopy-> ('伊藤荘','sou@gimal.com','sou54987',1),
internalcontactdbcopy-> ('松村荘','hama@gimal.com','82364460',2);
INSERT 0 2
internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |  tel_no  | role_id 
---------+-----------+----------------+----------+----------+---------
       1 | 伊藤荘    | sou@gimal.com  |          | sou54987 |       1
       2 | 松村荘    | hama@gimal.com |          | 82364460 |       2
(2 rows)

internalcontactdbcopy=> UPDATE users SET tel_no = '09078665432' WHERE user_id = 1;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET password = 'sou54987' WHERE user_id = 1;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET tel_no = '09078667543' WHERE user_id = 2;
UPDATE 1
internalcontactdbcopy=> UPDATE users SET password = 'hama7865' WHERE user_id = 2;
UPDATE 1
internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |   tel_no    | role_id 
---------+-----------+----------------+----------+-------------+---------
internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
            2 |          1 |                  | 2022-05-08      |       1
            3 |          1 |                  | 2022-05-08      |       1
            4 |          1 |                  | 2022-05-08      |       1
            5 |          1 |                  | 2022-05-08      |       1
            6 |          1 |                  | 2022-05-08      |       1
            7 |          1 |                  | 2022-05-08      |       1
            8 |          1 |                  | 2022-05-08      |       1
            9 |          1 |                  | 2022-05-08      |       1
           10 |          1 |                  | 2022-05-08      |       1
(10 rows)

internalcontactdbcopy=> \d sendmessage
internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
            2 |          1 |                  | 2022-05-08      |       1
            3 |          1 |                  | 2022-05-08      |       1
            4 |          1 |                  | 2022-05-08      |       1
            5 |          1 |                  | 2022-05-08      |       1
            6 |          1 |                  | 2022-05-08      |       1
            7 |          1 |                  | 2022-05-08      |       1
            8 |          1 |                  | 2022-05-08      |       1
            9 |          1 |                  | 2022-05-08      |       1
           10 |          1 |                  | 2022-05-08      |       1
           11 |          1 | テスト           | 2022-05-08      |       1
(11 rows)

internalcontactdbcopy=> delete from sendmessage where message_send = 2;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 3;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 4;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 5;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 6;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 7;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 8;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 9;
DELETE 1
internalcontactdbcopy=> delete from sendmessage where message_send = 10;
DELETE 1
internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
           11 |          1 | テスト           | 2022-05-08      |       1
(2 rows)

internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
           11 |          1 | テスト           | 2022-05-08      |       1
           12 |          1 | テスト           | 2022-05-08      |       1
           13 |          1 | テスト           | 2022-05-08      |       1
           14 |          1 | テスト           | 2022-05-08      |       1
           15 |          1 | テスト           | 2022-05-08      |       1
           16 |          1 | 組み込み型       | 2022-05-08      |       1
           17 |          1 | 組み込み型       | 2022-05-08      |       1
           18 |          1 | 組み込み型       | 2022-05-08      |       1
(9 rows)

internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |   tel_no    | role_id 
---------+-----------+----------------+----------+-------------+---------
       1 | 伊藤荘    | sou@gimal.com  | sou54987 | 09078665432 |       1
       2 | 松村荘    | hama@gimal.com | hama7865 | 09078667543 |       2
(2 rows)

internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
           11 |          1 | テスト           | 2022-05-08      |       1
           12 |          1 | テスト           | 2022-05-08      |       1
           13 |          1 | テスト           | 2022-05-08      |       1
           14 |          1 | テスト           | 2022-05-08      |       1
           15 |          1 | テスト           | 2022-05-08      |       1
           16 |          1 | 組み込み型       | 2022-05-08      |       1
           17 |          1 | 組み込み型       | 2022-05-08      |       1
           18 |          1 | 組み込み型       | 2022-05-08      |       1
           19 |          1 | 組み込み型       | 2022-05-08      |       1
           20 |          1 | テスト           | 2022-05-08      |       2
           21 |          2 | システムテスト   | 2022-05-08      |       2
           22 |          1 | テスト用         | 2022-05-08      |       2
           23 |          1 | テスト込み       | 2022-05-08      |       2
           24 |          1 | テスト           | 2022-05-08      |       2
           25 |          1 | テスト           | 2022-05-08      |       2
           26 |          1 | テスト           | 2022-05-08      |       2
(17 rows)

internalcontactdbcopy=> select * from sendmessage;
 message_send | message_id | sendmessage_text | create_datatime | user_id 
--------------+------------+------------------+-----------------+---------
            1 |          1 | 自動返信         | 2022-05-07      |       2
           11 |          1 | テスト           | 2022-05-08      |       1
           12 |          1 | テスト           | 2022-05-08      |       1
           13 |          1 | テスト           | 2022-05-08      |       1
           14 |          1 | テスト           | 2022-05-08      |       1
           15 |          1 | テスト           | 2022-05-08      |       1
           16 |          1 | 組み込み型       | 2022-05-08      |       1
           17 |          1 | 組み込み型       | 2022-05-08      |       1
           18 |          1 | 組み込み型       | 2022-05-08      |       1
           19 |          1 | 組み込み型       | 2022-05-08      |       1
           20 |          1 | テスト           | 2022-05-08      |       2
           21 |          2 | システムテスト   | 2022-05-08      |       2
           22 |          1 | テスト用         | 2022-05-08      |       2
           23 |          1 | テスト込み       | 2022-05-08      |       2
           24 |          1 | テスト           | 2022-05-08      |       2
           25 |          1 | テスト           | 2022-05-08      |       2
           26 |          1 | テスト           | 2022-05-08      |       2
(17 rows)

internalcontactdbcopy=> select * from message;
 message_id | message_title | message_text | create_datatime | user_id | group_id 
------------+---------------+--------------+-----------------+---------+----------
          1 | 社内日報      | 本日の内容は | 2022-02-18      |       1 |        1
          2 | システム研修  | 2月16日に    | 2022-02-18      |       1 |        2
(2 rows)

internalcontactdbcopy=> select * from sendmessage;
internalcontactdbcopy=> delete from sendmessage where message_send = 11;
DELETE 1
internalcontactdbcopy=> select * from sendmessage;
internalcontactdbcopy=> \d sendmessage
internalcontactdbcopy=> select * from users;
 user_id | user_name |    login_id    | password |   tel_no    | role_id 
---------+-----------+----------------+----------+-------------+---------
       1 | 伊藤荘    | sou@gimal.com  | sou54987 | 09078665432 |       1
       2 | 松村荘    | hama@gimal.com | hama7865 | 09078667543 |       2
       3 | 田井戸回  | kai@gimal.com  | Kai78965 | 09076543211 |       3
(3 rows)

internalcontactdbcopy=> 
