Last login: Mon Feb 28 09:09:37 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c postgrespl axizuser
Password for user axizuser: 
FATAL:  database "postgrespl" does not exist
Previous connection kept
postgres=# \c posgres axizuser
Password for user axizuser: 
FATAL:  database "posgres" does not exist
Previous connection kept
postgres=# \c posgres axizuser
Password for user axizuser: 
FATAL:  database "posgres" does not exist
Previous connection kept
postgres=# \c postgres axizuser
Password for user axizuser: 
You are now connected to database "postgres" as user "axizuser".
postgres=> \c dbconnection
You are now connected to database "dbconnection" as user "axizuser".
dbconnection=> select * from products;
 product_id | product_name | price 
------------+--------------+-------
        101 | 鉛筆         |    60
        102 | 消しゴム     |   200
        103 | 地球儀       |  5000
(3 rows)

dbconnection=> select * from products;
 product_id | product_name | price 
------------+--------------+-------
        101 | 鉛筆         |    60
        102 | 消しゴム     |   200
        103 | 地球儀       |  5000
(3 rows)

dbconnection=> select * from products where product_id;
ERROR:  argument of WHERE must be type boolean, not type integer
LINE 1: select * from products where product_id;
                                     ^
dbconnection=> select * from products where product_id;
ERROR:  argument of WHERE must be type boolean, not type integer
LINE 1: select * from products where product_id;
                                     ^
dbconnection=> select * from products where product_id = 101;
 product_id | product_name | price 
------------+--------------+-------
        101 | 鉛筆         |    60
(1 row)

dbconnection=> select * from products where product_id and product_name;
ERROR:  argument of AND must be type boolean, not type integer
LINE 1: select * from products where product_id and product_name;
                                     ^
dbconnection=> select * from products where product_id = 101 and product_name = '鉛筆';
 product_id | product_name | price 
------------+--------------+-------
        101 | 鉛筆         |    60
(1 row)

dbconnection=> select * from products where product_id;
ERROR:  argument of WHERE must be type boolean, not type integer
LINE 1: select * from products where product_id;
                                     ^
dbconnection=> select * from products where product_id = 101;
 product_id | product_name | price 
------------+--------------+-------
        101 | 鉛筆         |    60
(1 row)

dbconnection=> select product_id from produucts;
ERROR:  relation "produucts" does not exist
LINE 1: select product_id from produucts;
                               ^
dbconnection=> select product_id from products;
 product_id 
------------
        101
        102
        103
(3 rows)

dbconnection=> 
dbconnection=> \d produucts
Did not find any relation named "produucts".
dbconnection=> \d products
dbconnection=> \c axsizdb
FATAL:  database "axsizdb" does not exist
Previous connection kept
dbconnection=> \c axizdb;
You are now connected to database "axizdb" as user "axizuser".
axizdb=> select * fotm users;
ERROR:  syntax error at or near "fotm"
LINE 1: select * fotm users;
                 ^
axizdb=> select * from users;
 user_id | user_name |   tel_no    
---------+-----------+-------------
       1 | 田中      | 0311112222
     100 | testuser  | 0120
       2 | 鈴木      | 0571112222
      20 | 松本      | 0111122223
      10 | taro      | 01011112222
      11 | taro2     | 01011112222
(6 rows)

axizdb=> select * from users;
 user_id | user_name |   tel_no    
---------+-----------+-------------
       1 | 田中      | 0311112222
     100 | testuser  | 0120
       2 | 鈴木      | 0571112222
      20 | 松本      | 0111122223
      10 | taro      | 01011112222
      11 | taro2     | 01011112222
(6 rows)

axizdb=> DELETE FROM users WHERE user_id = 100;
DELETE 1
axizdb=> select * from users;
 user_id | user_name |   tel_no    
---------+-----------+-------------
       1 | 田中      | 0311112222
       2 | 鈴木      | 0571112222
      20 | 松本      | 0111122223
      10 | taro      | 01011112222
      11 | taro2     | 01011112222
(5 rows)

axizdb=> create database internalcontactdb;
CREATE DATABASE
internalcontactdb=> 
internalcontactdb=> create table role (
internalcontactdb(> role_id int primary key,
internalcontactdb(> role_name varchar(50)
internalcontactdb(> );
CREATE TABLE
internalcontactdb=> insert into role (role_id, role_name)values
internalcontactdb-> (1,'管理者'),(2,'一般'),(3,'リーダー');
INSERT 0 3
internalcontactdb=> select * from role;
 role_id | role_name 
---------+-----------
       1 | 管理者
       2 | 一般
       3 | リーダー
(3 rows)

internalcontactdb=> create table users (
internalcontactdb(> user_id serial primary key,
internalcontactdb(> user_name varchar(50),
internalcontactdb(> login_id varchar(50),
internalcontactdb(> password varchar(50),
internalcontactdb(> tel_no varchar(50),
internalcontactdb(> role_id int not references role(role_id)
internalcontactdb(> );
ERROR:  syntax error at or near "references"
LINE 7: role_id int not references role(role_id)
                        ^
internalcontactdb=> create table users (
internalcontactdb(> user_id serial primary key,
internalcontactdb(> user_name varchar(50),
internalcontactdb(> login_id varchar(50),
internalcontactdb(> password varchar(50),
internalcontactdb(> tel_no varchar(50),
internalcontactdb(> role_id int not null  references role(role_id)
internalcontactdb(> );
CREATE TABLE
internalcontactdb=> insert into users(user_name,login_id,tel_no,role_id)values
internalcontactdb-> ('伊藤壮','sou.@gmail.com','54926472','1'),
internalcontactdb-> ('松村浜','hama.@gmail.com','82364460',2);
INSERT 0 2
internalcontactdb=> select * from users;
 user_id | user_name |    login_id     | password |  tel_no  | role_id 
---------+-----------+-----------------+----------+----------+---------
       1 | 伊藤壮    | sou.@gmail.com  |          | 54926472 |       1
       2 | 松村浜    | hama.@gmail.com |          | 82364460 |       2
(2 rows)

internalcontactdb=> create table groups(
internalcontactdb(> group_id serial primary key,
internalcontactdb(> group_name varchar(50)
internalcontactdb(> );
CREATE TABLE
internalcontactdb=> insert into groups(group_name)values
internalcontactdb-> ('社内'),('システム部');
INSERT 0 2
internalcontactdb=> select * from groups;
 group_id | group_name 
----------+------------
        1 | 社内
        2 | システム部
(2 rows)

internalcontactdb=> create table user_group(
internalcontactdb(> management_id serial primary key,
internalcontactdb(> user_id int not null references users(user_id),
internalcontactdb(> group_id int not null references groups(group_id)
internalcontactdb(> );
CREATE TABLE
internalcontactdb=> insert into user_group(user_id,group_id)
internalcontactdb-> values(1,1),(1,2),(2,1),(2,2);
INSERT 0 4
internalcontactdb=> select * from user_group;
 management_id | user_id | group_id 
---------------+---------+----------
             1 |       1 |        1
             2 |       1 |        2
             3 |       2 |        1
             4 |       2 |        2
(4 rows)

internalcontactdb=> create table message(
internalcontactdb(> messsage_id serial primary key,
internalcontactdb(> message_title varchar(50),
internalcontactdb(> message_text text,
internalcontactdb(> create_datatime timestamp,
internalcontactdb(> user_id int not null references users(user_id),
internalcontactdb(> group_id int not null references groups(group_id)
internalcontactdb(> );
CREATE TABLE
internalcontactdb=> 
internalcontactdb=> insert into message(message_title,message_text,create_datatime,user_id,group_id)values
internalcontactdb-> ('社内日報','本日の内容は・・・','2022/2/18',1,1),('システム研修','2月16日に・','2022/2/18',1,2);
INSERT 0 2
internalcontactdb=> select * from message;
 messsage_id | message_title |    message_text    |   create_datatime   | user_id | group_id 
-------------+---------------+--------------------+---------------------+---------+----------
           1 | 社内日報      | 本日の内容は・・・ | 2022-02-18 00:00:00 |       1 |        1
           2 | システム研修  | 2月16日に・        | 2022-02-18 00:00:00 |       1 |        2
(2 rows)

internalcontactdb=> 
