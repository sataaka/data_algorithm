Last login: Mon Mar 28 17:34:21 on ttys000
/Library/PostgreSQL/13/scripts/runpsql.sh; exit
➜  ~ /Library/PostgreSQL/13/scripts/runpsql.sh; exit
Server [localhost]: 
Database [postgres]: 
Port [5432]: 
Username [postgres]: 
Password for user postgres: 
psql (13.5)
Type "help" for help.

postgres=# \c postgres axizuser
Password for user axizuser: 
You are now connected to database "postgres" as user "axizuser".
postgres=> \c internalcontactdb
You are now connected to database "internalcontactdb" as user "axizuser".
internalcontactdb=> SELECT * FROM users;
 user_id |        user_name         |    login_id     |  password   |    tel_no     | role_id 
---------+--------------------------+-----------------+-------------+---------------+---------
       2 | 松村浜                   | hama.@gmail.com | 82364460    | 82364460      |       2
      49 | 朝日                     | asahi@gmail.com | 112er452    | 090-8788-7676 |       1
      50 | 平平平平臍下珍内春寒衛門 | sou@gmail.com   | hirahira123 | 09078775432   |       1
      23 | 田井戸                   | sou.@gmail.com  | 12345678    | 090-8788-7676 |       1
      51 | 田井戸                   | hama@gmail.com  | 12yu67ty    | 09097554432   |       3
       1 | 伊藤壮                   | sou.@gmail.com  | 54926472    | 54926472      |       1
      26 | 田井戸                   | sou.@gmail.com  | 45678901    | 090-8788-7676 |       1
      47 | 田井戸                   | sou@gmail.com   | 12341234    | 090-8788-7676 |       1
      52 | 回廻                     | kai@gimal.com   | Tji89523    | 09045662321   |       1
      28 | 田井戸回                 | sou.@gmail.com  | 12356781    | 05067886755   |       1
(10 rows)

internalcontactdb=> 
internalcontactdb=> SELECT * FROM groups;
 group_id | group_name  
----------+-------------
        1 | 社内
        2 | システム部
        3 | 事務課
      125 | Linux
      126 | css
        6 | Webデザイン
        7 | 経理部
      127 | Library
      128 | Library
       68 | 経理部門
       95 | css
       97 | Mac
       42 | enjinya
       44 | Android
       45 | 管理部門
(15 rows)

internalcontactdb=> 
internalcontactdb=> SELECT * FROM user_group;
 management_id | user_id | group_id 
---------------+---------+----------
            20 |       1 |        1
            21 |       1 |        2
            22 |       1 |        3
            24 |       2 |        1
            25 |       2 |        2
            26 |      23 |        1
            27 |      23 |        3
           102 |      23 |       45
            29 |      26 |        1
            30 |      26 |        2
            31 |      47 |        1
           104 |       1 |       68
           105 |      26 |        3
            37 |      47 |        3
            38 |      47 |        2
            39 |      28 |        6
            40 |      47 |        6
            41 |       2 |        3
            42 |       2 |        6
           109 |      47 |        7
           121 |       1 |       95
           122 |      49 |       97
           123 |      28 |       97
           124 |      50 |       97
           125 |       1 |       97
            68 |      28 |       45
           137 |      49 |      125
           138 |       1 |      125
           139 |      47 |       42
           140 |      26 |      127
           141 |      49 |      127
           142 |       1 |      127
           143 |      52 |        1
(33 rows)

internalcontactdb=> SELECT * FROM message;
 message_id | message_title |             message_text             | create_datatime | user_id | group_id 
------------+---------------+--------------------------------------+-----------------+---------+----------
          3 | 社内日報      | 本日の業務は                         | 2023-02-18      |       1 |        1
          6 | 社内日報      | 本日の内容は・・・                   | 2022-02-18      |       1 |        1
          7 | システム研    | 2月16日に・                          | 2022-02-19      |       1 |        2
          8 | 研修          | テスト                               | 2023-02-18      |       1 |        1
         11 | 研修内容      | テスト                               | 2022-02-18      |       1 |        2
         13 | 社内日報      | テスト                               | 2022-02-18      |       1 |        6
         14 | 社内日報      | テスト                               | 2022-02-18      |      28 |        3
         15 | 社内日報      | 今日の業務連絡としては、\r          +| 2022-02-18      |       1 |        1
            |               | 管理者画面の作成をすることができた。 |                 |         | 
         16 | 社内日報      | テスト                               | 2022-02-18      |      23 |        2
         17 | 社内日報      | テスト                               | 2022-02-18      |      23 |        1
         18 | 研修日報      | テスト                               | 2022-03-22      |       1 |        2
         23 | 社内日報      | テスト                               | 2022-03-23      |      50 |        1
(12 rows)

internalcontactdb=> SELECT * FROM role;
 role_id | role_name 
---------+-----------
       1 | 管理者
       2 | 一般
       3 | リーダー
(3 rows)

internalcontactdb=> 
