#include <iostream>
using namespace std;

int main() {
    // for文の基本的な書き方
    for (int i = 0; i <= 10; i++) {
        cout << i << " ";
    }
    cout << endl;

    // for文で配列を処理する例
    int a[] = {1, 2, 3, 4, 5, 6, 7};
    int n = sizeof(a) / sizeof(a[0]);   // 4バイトで割っている。　つまり 7*4/4 = 7
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;

    return 0;
}
