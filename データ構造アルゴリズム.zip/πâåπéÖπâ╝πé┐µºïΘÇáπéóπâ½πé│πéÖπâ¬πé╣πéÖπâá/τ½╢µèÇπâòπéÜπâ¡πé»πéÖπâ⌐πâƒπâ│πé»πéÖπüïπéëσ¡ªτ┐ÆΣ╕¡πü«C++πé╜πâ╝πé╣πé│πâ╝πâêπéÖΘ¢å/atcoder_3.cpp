#include <iostream>

using namespace std;

int main()
{
    // 二次元配列の初期化
    int a[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };

    // 二次元配列の要素に対して 2 つの for ループを使用
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            a[i][j] *= 2;   // 要素を 2 倍にする
            //cout << a[i][j] << " "; これを利用すると改行せずに出力ができる。
        }
    }

    // 結果を表示
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
