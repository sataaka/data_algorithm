#include <iostream>
using namespace std;

double f(double a) { //f(a)という関数が使われている
    return 2.0 * a * a + a;
}

int main() {
    double a;   //7
    cin >> a;   //入力値
    cout << f(a) << endl;   //返り値
    return 0;
}