#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// 二分探索関数
int binary_search(vector<int> &data, int key) {
    int left = 0, right = data.size() - 1;  // 100だった場合は0〜100までを探す
    while (left <= right) {                 // 0 <= 100まで繰り返す
        int mid = (left + right) / 2;       // 0 + 99 /2 = 48
        if (data[mid] == key) {
            // キーが見つかった場合
            return mid;
        }
        else if (data[mid] < key) {             //もしキーが見つからなかったら、midに対して+1をして探す。
            // 中央値より大きい場合は右側を探索する
            left = mid + 1;
        }
        else {
            // 中央値より小さい場合は左側を探索する キーが中央値よりも低い場合は左側を探す
            right = mid - 1;
        }
    }
    // キーが見つからなかった場合
    return -1;
}

int main() {
    // ソート済みのデータを用意する
    vector<int> data = {1, 3, 5, 7, 9};

    // 探索するキーを指定する
    int key = 5;

    // 二分探索を実行する
    int result = binary_search(data, key);

    // 結果を表示する
    if (result == -1) {
        cout << "Not found" << endl;
    }
    else {
        cout << "Found at index " << result << endl;
    }

    return 0;
}
