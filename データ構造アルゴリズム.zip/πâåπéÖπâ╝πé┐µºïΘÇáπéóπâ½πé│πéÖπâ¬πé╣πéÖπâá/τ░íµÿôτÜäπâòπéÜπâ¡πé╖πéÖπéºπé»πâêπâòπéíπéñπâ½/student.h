/* student.h */

#ifndef STUDENT_H
#define STUDENT_H

struct student
{
    int year;       /* 学年 */
    int clas;       /* クラス */
    int number;     /* 出席番号 */
    char name[64];  /* 名前 */
    int suuti[3];
    double stature; /* 身長 */
    double weight;  /* 体重 */
};

#endif /* STUDENT_H */
