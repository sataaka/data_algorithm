/* main.c */

#include <stdio.h>
#include "student.h"

int main(void)
{
    struct student data;
    data.year = 10; /* year要素にアクセス */
    printf("Enter a number: ");
    scanf("%d", &data.suuti[0]); /* 入力部分 */
    printf("Entered number: %d\n", data.suuti[0]);
    printf("Year: %d\n", data.year);

    return 0;
}
