#include<stdio.h>
#include<string.h>

int main(void)
{
    /*const：変数の値を変更しない*/
    /*ポインタ：ポインタの利用により、hanteiメモリを確認した時に、文字列が確認できる*/
    const char *hantei[3] = {"aikodesu","hanakoWin!","tarouWin!"};

    int tarou;
    int hanako;
    int memori;

    for(int i = 0; i < 10; i++){

        printf("太郎:\n");
        scanf("%d",&tarou);
        printf("花子\n");
        scanf("%d",&hanako);

        if(tarou != hanako){
            memori = tarou + 1;

            if(memori > 3){
                memori = 1;
            }
            
            if(memori != hanako || hanako == 4){
                printf("hantei[%s]\n",hantei[1]);
            }else{
                printf("hatei[%s]\n",hantei[2]);
            };

        }else{
            printf("hantei[%s]\n",hantei[0]);
        }
    }
    
    return 0;


}