#include<stdio.h>
#include<string.h>

int main(void)
{
    int tarou;
    int hanako;
    int num;
    int array[4][4] = {
                            {2, 0, 1, 1},
                            {1, 2, 0, 1},
                            {0, 1, 2, 1},
                            {0, 0, 0, 2}    
    };

    char *p[3] = {"太郎の勝ち","花子の勝ち","あいこ"};

    for(int i = 0; i < 10; i++){
        printf("太郎\n");
        scanf("%d",&tarou);
        printf("花子\n");
        scanf("%d",&hanako);
        num = array[tarou][hanako];
        printf("%sです\n",p[num]);
        
        if(tarou == 4 || hanako == 4){
            tarou = 0;  //太郎のOKボタンを初期化
            hanako = 0; //花子のOKボタンを初期化
        }
    }

    return 0;
}