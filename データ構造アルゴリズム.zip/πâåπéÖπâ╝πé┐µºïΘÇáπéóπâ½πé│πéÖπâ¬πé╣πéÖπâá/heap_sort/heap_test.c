#include<stdio.h>
#define MAX_SIZE 8

void INSERT(int heap[], int childIndex);

int main(void)
{
    int N[MAX_SIZE] = {20,50,10,30,70,40,60,80};
    int heap[MAX_SIZE];

    printf("初期配列\n");
    for(int i = 0; i < MAX_SIZE; i++){
        heap[i] = N[i];
        printf("%d = [%d]\n",i,heap[i]);
    }
    
    for(int i = 1; i < MAX_SIZE; i++){
        INSERT(heap, i);
    }

    printf("heap後\n");
    for(int i = 0; i < MAX_SIZE; i++){
        printf("%d = [%d]\n",i,heap[i]);
    }

}

void INSERT(int heap[], int childIndex) {
        int child = childIndex;
        while(child > 0){
            //int parent = (child - 1) / 2;
            int parent = (child - 1) / 2;
            if(heap[child] > heap[parent]){
                int tmp = heap[parent];
                heap[parent] = heap[child];
                heap[child] = tmp;
            } else {
                break;
            }
            child = parent;
        }
}