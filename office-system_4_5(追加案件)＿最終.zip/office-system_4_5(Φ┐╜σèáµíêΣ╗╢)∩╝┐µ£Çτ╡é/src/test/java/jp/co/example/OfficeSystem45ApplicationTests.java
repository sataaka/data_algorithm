package jp.co.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeSystem45ApplicationTests {

	@Test
	void contextLoads() {
	}

}
